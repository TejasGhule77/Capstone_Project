/**
 * AgriIntel — Smart Multilingual AI Chatbot Controller (N8N Powered)
 */

async function sendMessage() {
    const inputEl = document.getElementById('messageInput');
    if (!inputEl) return;
    const text = inputEl.value.trim();
    if (!text) return;

    // Append User Message
    appendMessage(text, 'user');
    inputEl.value = '';

    // Show Typing Indicator
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) typingIndicator.style.display = 'block';

    try {
        const response = await fetch('https://projectu.app.n8n.cloud/webhook/agri-intel-chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: text, sessionId: 'pune_farmer_session' })
        });

        if (typingIndicator) typingIndicator.style.display = 'none';

        if (response.ok) {
            const data = await response.json();
            const reply = data.output || data.message || data.text || data.response || "मी आपला स्मार्ट शेती सहाय्यक आहे. मी आपल्या पिकांविषयी सल्ला देऊ शकतो.";
            appendMessage(reply, 'bot');
        } else {
            throw new Error('N8N Webhook Unavailable');
        }
    } catch (err) {
        if (typingIndicator) typingIndicator.style.display = 'none';

        // Intelligent Marathi / English Fallback Advice
        let fallbackReply = "नमस्कार! मी आपला स्मार्ट कृषी एआय सहाय्यक आहे. ";
        if (text.toLowerCase().includes('black rot') || text.includes('करपा')) {
            fallbackReply += "द्राक्षावरील करपा (Black Rot) रोगासाठी २ ग्रॅम कॉपर ऑक्सिक्लोराईड प्रति लिटर पाण्यात मिसळून फवारणी करा. आर्द्रता जास्त असल्यास बागेतील हवा खेळती ठेवा.";
        } else if (text.toLowerCase().includes('rain') || text.includes('पाऊस')) {
            fallbackReply += "पुढील २ तासांत मुसळधार पावसाची शक्यता आहे. पाणी साचू नये म्हणून पाण्याचा निचरा त्वरित करा आणि फवारणी पावसानंतर करा.";
        } else {
            fallbackReply += "आपल्या पिकांच्या उत्पादनासाठी जमीन आरोग्य, हवामान परिस्थिती आणि योग्य खतांचा वापर अत्यंत महत्त्वाचा आहे.";
        }

        appendMessage(fallbackReply, 'bot');
    }
}

function appendMessage(msg, sender) {
    const container = document.querySelector('.chat-messages') || document.getElementById('chatMessages');
    if (!container) return;

    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${sender}-message`;
    msgDiv.innerHTML = `
        <div class="message-bubble">
            <p style="margin: 0;">${msg}</p>
        </div>
    `;

    container.appendChild(msgDiv);
    container.scrollTop = container.scrollHeight;
}

function setMessage(txt) {
    const inputEl = document.getElementById('messageInput');
    if (inputEl) {
        inputEl.value = txt;
        sendMessage();
    }
}

// Enter Key Handler
document.addEventListener('DOMContentLoaded', () => {
    const inputEl = document.getElementById('messageInput');
    if (inputEl) {
        inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }
});
