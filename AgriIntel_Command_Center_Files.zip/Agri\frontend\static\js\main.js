/**
 * AgriIntel — Smart Farming Command Center Main JS, Location Selector & Bilingual i18n Engine
 */

// Location-based Weather Telemetry & Forecast Data
const locationWeatherData = {
    pune: {
        name_en: "Pune Region",
        name_mr: "पुणे विभाग",
        temp: "29°C",
        humidity: "82%",
        warning_en: "Impending heavy monsoon rain in Pune Vineyard over next 2 hours! Take precautions for Black Rot disease spread.",
        warning_mr: "पुढील २ तासांत पुणे द्राक्ष बागेत मुसळधार पावसाची शक्यता! करपा (Black Rot) संसर्गाची खबरदारी घ्या.",
        coords: "18.5204° N, 73.8567° E | Pune, MH",
        crop_focus_en: "Pune Vineyard",
        crop_focus_mr: "पुणे द्राक्ष बाग"
    },
    nashik: {
        name_en: "Nashik Region",
        name_mr: "नाशिक विभाग",
        temp: "27°C",
        humidity: "78%",
        warning_en: "Risk of downy mildew and thrips infestation in grape and onion crops due to overcast monsoon winds.",
        warning_mr: "वादळी हवामानामुळे द्राक्ष व कांदा पिकात तांबोरा व भुरी रोगाचा धोका! योग्य खबरदारी घ्या.",
        coords: "19.9975° N, 73.7898° E | Nashik, MH",
        crop_focus_en: "Nashik Grape & Onion Belt",
        crop_focus_mr: "नाशिक द्राक्ष व कांदा पट्टा"
    },
    kolhapur: {
        name_en: "Kolhapur Region",
        name_mr: "कोल्हापूर विभाग",
        temp: "31°C",
        humidity: "88%",
        warning_en: "Heavy torrential rainfall expected in sugarcane fields! Ensure proper field drainage to prevent root rot.",
        warning_mr: "अतिवृष्टीचा इशारा: उस पिकात पाणी साचण्याची शक्यता असल्यामुळे पाण्याचा निचरा त्वरित करा!",
        coords: "16.7050° N, 74.2433° E | Kolhapur, MH",
        crop_focus_en: "Kolhapur Sugarcane Belt",
        crop_focus_mr: "कोल्हापूर ऊस पट्टा"
    },
    sangli: {
        name_en: "Sangli Region",
        name_mr: "सांगली विभाग",
        temp: "32°C",
        humidity: "74%",
        warning_en: "Moderate rainfall alert. Recommended preventative bio-fungicide spray for turmeric and raisin vineyards.",
        warning_mr: "मध्यम पावसाचा अंदाज: हळद व द्राक्ष बागेत कीड व करपा नियंत्रणासाठी तातडीने फवारणी करा.",
        coords: "16.8524° N, 74.5815° E | Sangli, MH",
        crop_focus_en: "Sangli Turmeric & Grape Belt",
        crop_focus_mr: "सांगली हळद व द्राक्ष पट्टा"
    },
    satara: {
        name_en: "Satara Region",
        name_mr: "सातारा विभाग",
        temp: "26°C",
        humidity: "85%",
        warning_en: "Cool misty weather. Monitor strawberry and fruit orchards for early fungal leaf spot signs.",
        warning_mr: "पावसाची शक्यता: सातारा विभागातील स्ट्रॉबेरी व फळपिकांमध्ये बुरशीजन्य रोगांचा संसर्ग टाळा.",
        coords: "17.6805° N, 74.0183° E | Satara, MH",
        crop_focus_en: "Satara Strawberry & Fruit Belt",
        crop_focus_mr: "सातारा फळबाग पट्टा"
    },
    solapur: {
        name_en: "Solapur Region",
        name_mr: "सोलापूर विभाग",
        temp: "34°C",
        humidity: "65%",
        warning_en: "Hot dry weather. Maintain optimal drip irrigation schedule for pomegranate orchards.",
        warning_mr: "उष्ण व कोरडे हवामान: डाळिंब बागेस ठिबक सिंचनाने योग्य प्रमाणात पाणी देण्याचे नियोजन करा.",
        coords: "17.6599° N, 75.9064° E | Solapur, MH",
        crop_focus_en: "Solapur Pomegranate Belt",
        crop_focus_mr: "सोलापूर डाळिंब पट्टा"
    },
    nagpur: {
        name_en: "Nagpur Region",
        name_mr: "नागपूर विभाग",
        temp: "33°C",
        humidity: "70%",
        warning_en: "Thunderstorm warning. Inspect orange (citrus) groves and cotton crops for gummosis & pest risks.",
        warning_mr: "विजांसह पावसाचा इशारा: नागपूर संत्रा बागेत डिंक्या व कीड प्रादुर्भावावर सतत लक्ष ठेवा.",
        coords: "21.1458° N, 79.0882° E | Nagpur, MH",
        crop_focus_en: "Nagpur Citrus & Cotton Belt",
        crop_focus_mr: "नागपूर संत्रा व कापूस पट्टा"
    },
    sambhajinagar: {
        name_en: "Chh. Sambhajinagar Region",
        name_mr: "छत्रपती संभाजीनगर विभाग",
        temp: "32°C",
        humidity: "68%",
        warning_en: "Light rain showers expected. Take pest control measures in cotton and maize fields.",
        warning_mr: "हलक्या पावसाची शक्यता: कापूस व मका पिकात लाल्या रोग व कीड नियंत्रणाचे उपाय करा.",
        coords: "19.8762° N, 75.3433° E | Sambhajinagar, MH",
        crop_focus_en: "Chh. Sambhajinagar Cotton & Maize Belt",
        crop_focus_mr: "छत्रपती संभाजीनगर कापूस व मका पट्टा"
    }
};

// Comprehensive i18n Translations Dictionary (English ↔ Marathi)
const translations = {
    en: {
        // Navigation & Top Bar
        command_center_badge: "Command Center v2.5",
        nav_dashboard: "Dashboard",
        nav_yield: "Yield Predictions",
        nav_disease: "Disease Detection",
        nav_crop_rec: "Crop & Fertilizer",
        nav_market: "Market Predictions",
        nav_pest: "Pest Predictions",
        nav_reports: "Reports & Charts",
        nav_ai_bot: "🤖 AI Chatbot",
        lbl_select_region: "Region:",

        // Hero Banner & Cards
        hero_title: "📍 Smart Farming Command Center",
        hero_subtitle: "Real-time agricultural intelligence, AI disease diagnostics, and micro-climate weather radar.",
        live_status: "Live Telemetry Sync (Django API)",

        weather_module_title: "⚡ Weather Intelligence Module",
        lbl_temp: "Temperature",
        lbl_humidity: "Humidity",
        alert_header: "Warning:",
        rain_warning_text: "Impending heavy monsoon rain in Pune Vineyard over next 2 hours! Take precautions for Black Rot disease spread.",

        radar_title: "🛰️ Vineyard Doppler Radar Map",
        iot_active: "3 IoT Sensors",
        radar_footer: "Field Coordinates: 18.5204° N, 73.8567° E | Pune, MH",

        ai_diag_title: "🤖 Smart Multilingual AI Diagnostic",
        conf_badge: "94% Confidence",
        ai_detected_disease: "Detected: Black Rot (Guignardia bidwellii)",
        leaf_render_title: "3D Leaf Render Analysis",
        leaf_render_desc: "Leaf spot lesion index: High risk due to humidity.",
        btn_consult_ai: "💬 Consult AI Assistant (Chatbot)",

        // Dashboard
        dashboard_section_title: "Smart Agriculture Dashboard",
        stat_card_title: "Prediction Statistics",
        stat_avg_yield: "Avg Yield (tons/ha)",
        stat_weather: "Weather Impact",
        stat_ndvi: "Avg NDVI",
        stat_confidence: "AI Confidence",

        quick_actions_title: "Quick Actions",
        btn_yield_pred: "Yield Predictions",
        btn_disease_det: "Disease Detection",
        btn_market_pred: "Market Predictions",
        btn_pest_pred: "Pest Predictions",

        recent_activity_title: "Recent Activity",
        act_1: "Weather Intelligence Alert triggered for active farm region",
        act_2: "Black Rot Disease Diagnosis completed (94% confidence)",
        act_3: "IoT Sensor node telemetry synced with Django API",

        sys_status_title: "System Status",
        sys_ml: "ML Models (ResNet18 / XGBoost)",
        sys_data: "Django REST API",
        sys_weather: "Weather Radar Feed",

        // Section Headers & Instructions
        lbl_how_to_use: "How to use:",
        yield_sec_title: "Crop Yield Predictions",
        yield_form_title: "Enter Farm Data for Yield Prediction",
        yield_how_to_use: "Enter the farm conditions and crop details to predict yield. All fields are required for accurate predictions.",

        disease_sec_title: "Plant Disease Detection",
        disease_form_title: "Upload Leaf Image for Disease Detection",
        disease_how_to_use: "Upload a clear photo of a plant leaf showing signs of disease. The system will analyze the image and provide disease identification and treatment advice.",

        rec_sec_title: "Crop & Fertilizer Recommendations",
        rec_form_title: "Enter Your Farm Conditions",
        rec_how_to_use: "Enter the soil conditions and weather data for your farm. The system will recommend the best crops to plant and the appropriate fertilizers to use.",
        rec_soil_note: "Note: All values should be for the top 15 cm of soil.",

        market_sec_title: "Market Price Predictions",
        market_form_title: "Predict Crop Market Prices",
        market_how_to_use: "Enter crop details and conditions to predict future market prices. This helps you make informed decisions about when to sell your crops for maximum profit.",

        pest_sec_title: "Pest Prediction",
        pest_form_title: "Enter Farm Data for Pest Prediction",
        pest_how_to_use: "Enter the farm conditions and crop details to predict potential pest occurrences. All fields are required for accurate predictions.",

        reports_sec_title: "Reports & Charts",
        reports_form_title: "Generate Agricultural Reports",
        reports_how_to_use: "Select the type of report you want to generate and the time period. The system will create visual charts and data summaries for your agricultural activities.",

        // Result Card Titles
        title_pred_results: "Prediction Results",
        title_disease_results: "Disease Detection Results",
        title_treatment_advice: "Treatment Advice",
        title_rec_results: "Recommendation Results",
        title_market_results: "Market Prediction Results",
        title_pest_results: "Pest Prediction Results",
        title_report_results: "Report Results",

        // Field Labels
        lbl_region: "Region:",
        lbl_soil_type: "Soil Type:",
        lbl_crop: "Crop:",
        lbl_rainfall_mm: "Rainfall (mm):",
        lbl_temp_celsius: "Temperature (°C):",
        lbl_days_harvest: "Days to Harvest:",
        lbl_fert_used: "Fertilizer Used:",
        lbl_irrig_used: "Irrigation Used:",
        lbl_weather_cond: "Weather Condition:",
        lbl_upload_leaf: "Upload Leaf Image (JPG, PNG):",
        lbl_soil_n: "Soil Nitrogen (kg/ha):",
        lbl_soil_p: "Soil Phosphorus (kg/ha):",
        lbl_soil_k: "Soil Potassium (kg/ha):",
        lbl_soil_ph: "Soil pH:",
        lbl_temperature: "Temperature (°C):",
        lbl_humidity_rec: "Humidity (%):",
        lbl_rainfall: "Rainfall (mm):",
        lbl_location: "Location (State/Region):",
        lbl_season: "Season:",
        lbl_exp_yield: "Expected Yield (tons/ha):",
        lbl_global_demand: "Global Demand:",
        lbl_weather_impact: "Weather Impact:",
        lbl_econ_cond: "Economic Condition:",
        lbl_supply_idx: "Supply Index (0-100):",
        lbl_demand_idx: "Demand Index (0-100):",
        lbl_inv_level: "Inventory Level (0-100):",
        lbl_export_demand: "Export Demand (0-100):",
        lbl_prod_cost: "Production Cost ($/ton):",
        lbl_fert_usage: "Fertilizer Usage:",
        lbl_irrig_usage: "Irrigation Usage:",
        lbl_wind_speed: "Wind Speed (km/h):",
        lbl_soil_moisture: "Soil Moisture (%):",
        lbl_irrig_method: "Irrigation Method:",
        lbl_prev_crop: "Previous Crop:",
        lbl_days_planting: "Days Since Planting:",
        lbl_plant_density: "Plant Density (plants/ha):",
        lbl_report_type: "Report Type:",
        lbl_time_range: "Time Range:",

        // Help Texts
        help_farm_region: "Geographical region of the farm",
        help_soil_type: "Type of soil in the farm",
        help_crop: "Type of crop being grown",
        help_rainfall_mm: "Annual or seasonal rainfall in millimeters",
        help_temp_celsius: "Average temperature in Celsius",
        help_days_harvest: "Number of days until harvest",
        help_fert_used: "Whether fertilizer is being used",
        help_irrig_used: "Whether irrigation is being used",
        help_weather_cond: "Current weather condition",
        help_leaf_image: "For best results, ensure the image is clear and well-lit",
        help_soil_n: "Amount of nitrogen in the soil",
        help_soil_p: "Amount of phosphorus in the soil",
        help_soil_k: "Amount of potassium in the soil",
        help_soil_ph: "Soil acidity level (0-14 scale)",
        help_temperature: "Average temperature in your area",
        help_humidity: "Average humidity level",
        help_rainfall: "Monthly rainfall amount",
        help_location: "Your general location",
        help_season: "Current growing season",
        help_exp_yield: "Predicted yield from your yield prediction",
        help_global_demand: "Expected global demand level",
        help_weather_impact: "Impact of weather on crop production",
        help_econ_cond: "Current economic conditions",
        help_supply_idx: "Supply level indicator",
        help_demand_idx: "Demand level indicator",
        help_inv_level: "Current inventory levels",
        help_export_demand: "Export demand level",
        help_prod_cost: "Production cost per ton",
        help_fert_usage: "Fertilizer usage level",
        help_irrig_usage: "Irrigation usage level",
        help_wind_speed: "Average wind speed",
        help_soil_moisture: "Soil moisture content",
        help_irrig_method: "Type of irrigation used",
        help_prev_crop: "Crop grown in this field previously",
        help_days_planting: "Number of days since crop was planted",
        help_plant_density: "Number of plants per hectare",

        // Select Options
        opt_select_region: "Select Region",
        opt_north: "North",
        opt_south: "South",
        opt_east: "East",
        opt_west: "West",
        opt_central: "Central",
        opt_northeast: "Northeast",
        opt_southeast: "Southeast",
        opt_northwest: "Northwest",
        opt_southwest: "Southwest",

        opt_select_soil_type: "Select Soil Type",
        opt_clay: "Clay",
        opt_sandy: "Sandy",
        opt_loam: "Loam",
        opt_silt: "Silt",
        opt_peat: "Peat",
        opt_chalky: "Chalky",

        opt_select_crop: "Select Crop",
        opt_wheat: "Wheat",
        opt_rice: "Rice",
        opt_maize: "Maize",
        opt_barley: "Barley",
        opt_soybean: "Soybean",
        opt_cotton: "Cotton",
        opt_sugarcane: "Sugarcane",
        opt_potato: "Potato",
        opt_tomato: "Tomato",
        opt_coffee: "Coffee",
        opt_tea: "Tea",

        opt_select_opt: "Select Option",
        opt_yes: "Yes",
        opt_no: "No",

        opt_select_cond: "Select Condition",
        opt_sunny: "Sunny",
        opt_cloudy: "Cloudy",
        opt_rainy: "Rainy",
        opt_windy: "Windy",
        opt_stormy: "Stormy",
        opt_humid: "Humid",

        opt_select_season: "Select Season",
        opt_spring: "Spring",
        opt_summer: "Summer",
        opt_autumn: "Autumn/Fall",
        opt_winter: "Winter",

        opt_demand_medium: "Medium (Default)",
        opt_demand_high: "High",
        opt_demand_low: "Low",

        opt_impact_normal: "Normal (Default)",
        opt_impact_poor: "Poor",
        opt_impact_excellent: "Excellent",

        opt_econ_stable: "Stable",
        opt_econ_growth: "Growth",
        opt_econ_recession: "Recession",

        opt_level_medium: "Medium",
        opt_level_low: "Low",
        opt_level_high: "High",

        opt_select_method: "Select Method",
        opt_irrig_drip: "Drip",
        opt_irrig_sprinkler: "Sprinkler",
        opt_irrig_furrow: "Furrow",
        opt_irrig_flood: "Flood",
        opt_none: "None",

        opt_rep_predictions: "Predictions Report",
        opt_rep_diseases: "Disease Detection Report",
        opt_rep_recommendations: "Recommendations Report",
        opt_rep_pests: "Pest Predictions Report",
        opt_rep_market: "Market Predictions Report",

        opt_time_7: "Last 7 Days",
        opt_time_30: "Last 30 Days",
        opt_time_90: "Last 90 Days",
        opt_time_365: "Last Year",

        // Buttons
        btn_predict_yield: "Predict Yield",
        btn_analyze_diseases: "Analyze for Diseases",
        btn_get_rec: "Get Recommendations",
        btn_predict_market: "Predict Market Price",
        btn_predict_pest: "Predict Pest Occurrence",
        btn_gen_report: "Generate Report",
        btn_dl_pdf: "Download PDF",

        // Placeholders
        ph_eg_rainfall: "e.g., 800.5",
        ph_eg_temp: "e.g., 25.3",
        ph_eg_days: "e.g., 120",
        ph_eg_n: "e.g., 120.5",
        ph_eg_p: "e.g., 45.2",
        ph_eg_k: "e.g., 90.8",
        ph_eg_ph: "e.g., 6.5",
        ph_eg_humidity: "e.g., 65.0",
        ph_eg_location: "e.g., California",
        ph_eg_exp_yield: "e.g., 3.5",
        ph_eg_wind: "e.g., 15.5",
        ph_eg_moisture: "e.g., 45.0",
        ph_eg_days_plant: "e.g., 60",
        ph_eg_density: "e.g., 50000",
        ph_ask_anything: "Ask me anything about farming...",

        // Chatbot & Hints
        chat_header_title: "AgriIntel AI Assistant",
        chat_status_connecting: "Connecting...",
        chat_welcome_intro: "👋 Hello! I'm your AgriIntel AI Assistant. I can help you with:",
        chat_feat_1: "🌾 Crop recommendations and yield predictions",
        chat_feat_2: "🌡️ Weather and climate advice",
        chat_feat_3: "🧪 Soil analysis and fertilizer suggestions",
        chat_feat_4: "🐛 Pest and disease identification",
        chat_feat_5: "📈 Market price forecasts",
        chat_feat_6: "💡 General farming best practices",
        chat_welcome_outro: "How can I assist you today?",
        msg_just_now: "Just now",
        chip_crop_rec: "🌱 Crop recommendations",
        chip_soil_imp: "🌾 Soil improvement",
        chip_market_price: "💰 Market prices"
    },
    mr: {
        // Navigation & Top Bar
        command_center_badge: "स्मार्ट कृषी केंद्र v2.5",
        nav_dashboard: "डॅशबोर्ड",
        nav_yield: "उत्पादन अंदाज",
        nav_disease: "रोग निदान",
        nav_crop_rec: "पिक व खत सल्ला",
        nav_market: "बाजारभाव अंदाज",
        nav_pest: "कीड अंदाज",
        nav_reports: "अहवाल व तक्ते",
        nav_ai_bot: "🤖 एआय कृषी सहाय्यक",
        lbl_select_region: "विभाग:",

        // Hero Banner & Cards
        hero_title: "📍 स्मार्ट फार्मिंग कमांड सेंटर",
        hero_subtitle: "रिअल-टाइम कृषी बुद्धिमत्ता, वनस्पती रोग निदान आणि सूक्ष्म-हवामान रडार.",
        live_status: "थेट डेटा सिंक (Django API)",

        weather_module_title: "⚡ हवामान बुद्धिमत्ता मॉड्यूल",
        lbl_temp: "तापमान (°C)",
        lbl_humidity: "आर्द्रता (%)",
        alert_header: "इशारा / सूचना:",
        rain_warning_text: "पुढील २ तासांत पुणे द्राक्ष बागेत मुसळधार पावसाची शक्यता! करपा (Black Rot) संसर्गाची खबरदारी घ्या.",

        radar_title: "🛰️ कृषी डॉप्लर रडार मॅप",
        iot_active: "३ आयओटी सेन्सर सक्रिय",
        radar_footer: "स्थानिक निर्देशांक: 18.5204° N, 73.8567° E | पुणे, महाराष्ट्र",

        ai_diag_title: "🤖 स्मार्ट बहुभाषिक एआय निदान",
        conf_badge: "९४% अचूकता",
        ai_detected_disease: "निदान: द्राक्षाचा करपा रोग (Black Rot / Guignardia bidwellii)",
        leaf_render_title: "३डी पान विश्लेषण प्रणाली",
        leaf_render_desc: "आर्द्रतेमुळे पानांवर करपा रोगाचा उच्च धोका दर्शवत आहे.",
        btn_consult_ai: "💬 एआय सहाय्यकाला विचारा (मराठीत)",

        // Dashboard
        dashboard_section_title: "स्मार्ट कृषी डॅशबोर्ड",
        stat_card_title: "अंदाज सांख्यिकी",
        stat_avg_yield: "सरासरी उत्पादन (टन/हेक्टर)",
        stat_weather: "हवामान प्रभाव",
        stat_ndvi: "सरासरी NDVI निर्देशांक",
        stat_confidence: "एआय अचूकता दर",

        quick_actions_title: "जलद कृती",
        btn_yield_pred: "उत्पादन अंदाज",
        btn_disease_det: "रोग निदान",
        btn_market_pred: "बाजारभाव अंदाज",
        btn_pest_pred: "कीड अंदाज",

        recent_activity_title: "नुकत्याच झालेल्या घडामोडी",
        act_1: "निवडलेल्या शेत विभागासाठी हवामान इशारा जारी करण्यात आला",
        act_2: "करपा रोगाचे निदान पूर्ण झाले (९४% अचूकता)",
        act_3: "आयओटी सेन्सर डेटा Django बॅकएंडशी जोडला गेला",

        sys_status_title: "प्रणाली स्थिती",
        sys_ml: "एमएल मॉडेल्स (ResNet18 / XGBoost)",
        sys_data: "Django REST एपीआय",
        sys_weather: "हवामान रडार फीड",

        // Section Headers & Instructions
        lbl_how_to_use: "कसे वापरावे:",
        yield_sec_title: "पिक उत्पादन अंदाज",
        yield_form_title: "उत्पादन अंदाजासाठी शेताची माहिती भरा",
        yield_how_to_use: "उत्पादनाचा अंदाज घेण्यासाठी शेताची परिस्थिती आणि पिकाची माहिती प्रविष्ट करा. अचूक अंदाजासाठी सर्व माहिती भरणे आवश्यक आहे.",

        disease_sec_title: "वनस्पती रोग निदान",
        disease_form_title: "रोग निदानासाठी पानाचे छायाचित्र अपलोड करा",
        disease_how_to_use: "रोगाची लक्षणे दिसणाऱ्या वनस्पतीच्या पानाचे स्पष्ट छायाचित्र अपलोड करा. प्रणाली छायाचित्राचे विश्लेषण करून रोग व त्यावरील उपचारांचा सल्ला देईल.",

        rec_sec_title: "पिक व खत शिफारसी",
        rec_form_title: "तुमच्या शेतातील परिस्थिती प्रविष्ट करा",
        rec_how_to_use: "तुमच्या शेतातील मातीची परिस्थिती आणि हवामानाचा डेटा प्रविष्ट करा. प्रणाली योग्य पिके आणि खतांची शिफारस करेल.",
        rec_soil_note: "टीप: सर्व मूल्ये मातीच्या वरच्या १५ सेमी भागासाठी असावीत.",

        market_sec_title: "बाजारभाव अंदाज",
        market_form_title: "पिकांच्या बाजारभावाचा अंदाज लावा",
        market_how_to_use: "भविष्यातील बाजारभावाचा अंदाज घेण्यासाठी पिकाचे तपशील आणि परिस्थिती प्रविष्ट करा. यामुळे जास्तीत जास्त नफ्यासाठी माल कधी विकावा याचा निर्णय घेण्यास मदत होते.",

        pest_sec_title: "कीड प्रादुर्भाव अंदाज",
        pest_form_title: "कीड अंदाजासाठी शेताची माहिती प्रविष्ट करा",
        pest_how_to_use: "संभाव्य कीड प्रादुर्भावाचा अंदाज घेण्यासाठी शेतातील परिस्थिती आणि पिकाची माहिती प्रविष्ट करा. अचूक अंदाजासाठी सर्व माहिती आवश्यक आहे.",

        reports_sec_title: "अहवाल व आलेख",
        reports_form_title: "कृषी अहवाल तयार करा",
        reports_how_to_use: "तुम्हाला तयार करावयाचा अहवाल आणि कालावधी निवडा. प्रणाली तुमच्या कृषी उपक्रमांसाठी आलेखासह सारांश तयार करेल.",

        // Result Card Titles
        title_pred_results: "उत्पादन अंदाज निकाल",
        title_disease_results: "रोग निदान निकाल",
        title_treatment_advice: "उपचार व उपाययोजना",
        title_rec_results: "शिफारस निकाल",
        title_market_results: "बाजारभाव अंदाज निकाल",
        title_pest_results: "कीड अंदाज निकाल",
        title_report_results: "अहवाल निकाल",

        // Field Labels
        lbl_region: "विभाग:",
        lbl_soil_type: "मातीचा प्रकार:",
        lbl_crop: "पिक:",
        lbl_rainfall_mm: "पाऊस (मिमी):",
        lbl_temp_celsius: "तापमान (°C):",
        lbl_days_harvest: "काढणीसाठी दिवस:",
        lbl_fert_used: "खत वापरले आहे का:",
        lbl_irrig_used: "सिंचन वापरले आहे का:",
        lbl_weather_cond: "हवामान स्थिती:",
        lbl_upload_leaf: "पानाचे छायाचित्र अपलोड करा (JPG, PNG):",
        lbl_soil_n: "मातीतील नत्र (किलो/हेक्टर):",
        lbl_soil_p: "मातीतील स्फुरद (किलो/हेक्टर):",
        lbl_soil_k: "मातीतील पालाश (किलो/हेक्टर):",
        lbl_soil_ph: "मातीचा सामू (pH):",
        lbl_temperature: "तापमान (°C):",
        lbl_humidity_rec: "आर्द्रता (%):",
        lbl_rainfall: "पाऊस (मिमी):",
        lbl_location: "स्थान (राज्य/विभाग):",
        lbl_season: "हंगाम:",
        lbl_exp_yield: "अपेक्षित उत्पादन (टन/हेक्टर):",
        lbl_global_demand: "जागतिक मागणी:",
        lbl_weather_impact: "हवामानाचा प्रभाव:",
        lbl_econ_cond: "आर्थिक स्थिती:",
        lbl_supply_idx: "पुरवठा निर्देशांक (0-100):",
        lbl_demand_idx: "मागणी निर्देशांक (0-100):",
        lbl_inv_level: "साठा पातळी (0-100):",
        lbl_export_demand: "निर्यात मागणी (0-100):",
        lbl_prod_cost: "उत्पादन खर्च ($/टन):",
        lbl_fert_usage: "खत वापर प्रमाण:",
        lbl_irrig_usage: "सिंचन वापर प्रमाण:",
        lbl_wind_speed: "वाऱ्याचा वेग (किमी/तास):",
        lbl_soil_moisture: "मातीतील ओलावा (%):",
        lbl_irrig_method: "सिंचन पद्धत:",
        lbl_prev_crop: "मागील पिक:",
        lbl_days_planting: "लागवडीनंतरचे दिवस:",
        lbl_plant_density: "रोपांची घनता (रोपे/हेक्टर):",
        lbl_report_type: "अहवाल प्रकार:",
        lbl_time_range: "कालावधी:",

        // Help Texts
        help_farm_region: "शेताचा भौगोलिक भाग",
        help_soil_type: "शेतातील मातीचा प्रकार",
        help_crop: "घेतल्या जाणाऱ्या पिकाचा प्रकार",
        help_rainfall_mm: "वार्षिक किंवा हंगामी पाऊस (मिलीमीटर)",
        help_temp_celsius: "सरासरी तापमान (सेल्सिअस)",
        help_days_harvest: "काढणीसाठी उर्वरित दिवस",
        help_fert_used: "खताचा वापर केला जात आहे का",
        help_irrig_used: "सिंचनाचा वापर केला जात आहे का",
        help_weather_cond: "सध्याची हवामान स्थिती",
        help_leaf_image: "उत्कृष्ट निकालासाठी छायाचित्र स्पष्ट आणि पुरेशा प्रकाशात घेतलेले असावे",
        help_soil_n: "मातीतील नत्राचे प्रमाण",
        help_soil_p: "मातीतील स्फुरदाचे प्रमाण",
        help_soil_k: "मातीतील पालाशाचे प्रमाण",
        help_soil_ph: "मातीचा सामू (० ते १४ स्केल)",
        help_temperature: "तुमच्या परिसरातील सरासरी तापमान",
        help_humidity: "सरासरी आर्द्रता पातळी",
        help_rainfall: "मासिक पावसाचे प्रमाण",
        help_location: "तुमचे सर्वसाधारण स्थान",
        help_season: "सध्याचा पीक हंगाम",
        help_exp_yield: "उत्पादन अंदाजावरून मिळालेले अपेक्षित उत्पादन",
        help_global_demand: "अपेक्षित जागतिक मागणी पातळी",
        help_weather_impact: "पिक उत्पादनावरील हवामानाचा प्रभाव",
        help_econ_cond: "सध्याची आर्थिक परिस्थिती",
        help_supply_idx: "पुरवठा पातळी दर्शक",
        help_demand_idx: "मागणी पातळी दर्शक",
        help_inv_level: "सध्याची साठा पातळी",
        help_export_demand: "निर्यात मागणी पातळी",
        help_prod_cost: "प्रति टन उत्पादन खर्च",
        help_fert_usage: "खताच्या वापराचे प्रमाण",
        help_irrig_usage: "सिंचनाच्या वापराचे प्रमाण",
        help_wind_speed: "वाऱ्याचा सरासरी वेग",
        help_soil_moisture: "मातीतील ओलाव्याचे प्रमाण",
        help_irrig_method: "वापरलेली सिंचन पद्धत",
        help_prev_crop: "या शेतात आधी घेतलेले पिक",
        help_days_planting: "पिकाच्या लागवडीनंतरचे दिवस",
        help_plant_density: "प्रति हेक्टर रोपांची संख्या",

        // Select Options
        opt_select_region: "विभाग निवडा",
        opt_north: "उत्तर",
        opt_south: "दक्षिण",
        opt_east: "पूर्व",
        opt_west: "पश्चिम",
        opt_central: "मध्य",
        opt_northeast: "ईशान्य",
        opt_southeast: "आग्नेय",
        opt_northwest: "वायव्य",
        opt_southwest: "नैऋत्य",

        opt_select_soil_type: "मातीचा प्रकार निवडा",
        opt_clay: "काळी माती (चिखलमय)",
        opt_sandy: "वाळूमय माती",
        opt_loam: "पोयटा माती",
        opt_silt: "गाळाची माती",
        opt_peat: "दलदलीची माती",
        opt_chalky: "चुनायुक्त माती",

        opt_select_crop: "पिक निवडा",
        opt_wheat: "गहू",
        opt_rice: "तांदूळ (भात)",
        opt_maize: "मका",
        opt_barley: "जव (बारली)",
        opt_soybean: "सोयाबीन",
        opt_cotton: "कापूस",
        opt_sugarcane: "ऊस",
        opt_potato: "बटाटा",
        opt_tomato: "टोमॅटो",
        opt_coffee: "कॉफी",
        opt_tea: "चहा",

        opt_select_opt: "पर्याय निवडा",
        opt_yes: "होय",
        opt_no: "नाही",

        opt_select_cond: "स्थिती निवडा",
        opt_sunny: "उन्हाळी (स्वच्छ)",
        opt_cloudy: "ढगाळ",
        opt_rainy: "पावसाळी",
        opt_windy: "वादळी / वादळवारा",
        opt_stormy: "मुसळधार वादळी",
        opt_humid: "दमट",

        opt_select_season: "हंगाम निवडा",
        opt_spring: "वसंत (रब्बी/उन्हाळी)",
        opt_summer: "उन्हाळा (झैद)",
        opt_autumn: "शरद (खरीप)",
        opt_winter: "हिवाळा (रब्बी)",

        opt_demand_medium: "मध्यम (डीफॉल्ट)",
        opt_demand_high: "उच्च",
        opt_demand_low: "कमी",

        opt_impact_normal: "सामान्य (डीफॉल्ट)",
        opt_impact_poor: "प्रतिकूल",
        opt_impact_excellent: "अनुकूल / उत्तम",

        opt_econ_stable: "स्थिर",
        opt_econ_growth: "वाढ",
        opt_econ_recession: "मंदी",

        opt_level_medium: "मध्यम",
        opt_level_low: "कमी",
        opt_level_high: "जास्त",

        opt_select_method: "पद्धत निवडा",
        opt_irrig_drip: "ठिबक सिंचन",
        opt_irrig_sprinkler: "तुषार सिंचन",
        opt_irrig_furrow: "सरी-वरंबा पद्धत",
        opt_irrig_flood: "मोकळे पाणी (पाटाचे)",
        opt_none: "काहीही नाही",

        opt_rep_predictions: "उत्पादन अंदाज अहवाल",
        opt_rep_diseases: "रोग निदान अहवाल",
        opt_rep_recommendations: "पिक शिफारस अहवाल",
        opt_rep_pests: "कीड अंदाज अहवाल",
        opt_rep_market: "बाजारभाव अहवाल",

        opt_time_7: "मागील ७ दिवस",
        opt_time_30: "मागील ३० दिवस",
        opt_time_90: "मागील ९० दिवस",
        opt_time_365: "मागील १ वर्ष",

        // Buttons
        btn_predict_yield: "उत्पादनाचा अंदाज घ्या",
        btn_analyze_diseases: "रोगाचे विश्लेषण करा",
        btn_get_rec: "शिफारस मिळवा",
        btn_predict_market: "बाजारभावाचा अंदाज घ्या",
        btn_predict_pest: "कीड प्रादुर्भावाचा अंदाज घ्या",
        btn_gen_report: "अहवाल तयार करा",
        btn_dl_pdf: "PDF डाउनलोड करा",

        // Placeholders
        ph_eg_rainfall: "उदा. ८००.५",
        ph_eg_temp: "उदा. २५.३",
        ph_eg_days: "उदा. १२०",
        ph_eg_n: "उदा. १२०.५",
        ph_eg_p: "उदा. ४५.२",
        ph_eg_k: "उदा. ९०.८",
        ph_eg_ph: "उदा. ६.५",
        ph_eg_humidity: "उदा. ६५.०",
        ph_eg_location: "उदा. पुणे, महाराष्ट्र",
        ph_eg_exp_yield: "उदा. ३.५",
        ph_eg_wind: "उदा. १५.५",
        ph_eg_moisture: "उदा. ४५.०",
        ph_eg_days_plant: "उदा. ६०",
        ph_eg_density: "उदा. ५००००",
        ph_ask_anything: "शेतीबद्दल काहीही विचारा...",

        // Chatbot & Hints
        chat_header_title: "AgriIntel एआय कृषी सहाय्यक",
        chat_status_connecting: "जोडत आहे...",
        chat_welcome_intro: "👋 नमस्कार! मी तुमचा AgriIntel एआय कृषी सहाय्यक आहे. मी तुम्हाला खालील गोष्टींमध्ये मदत करू शकतो:",
        chat_feat_1: "🌾 पिक शिफारसी आणि उत्पादन अंदाज",
        chat_feat_2: "🌡️ हवामान आणि हवामान विषयक सल्ला",
        chat_feat_3: "🧪 माती विश्लेषण आणि खत शिफारसी",
        chat_feat_4: "🐛 कीड आणि रोग ओळखणे",
        chat_feat_5: "📈 बाजारभाव अंदाज",
        chat_feat_6: "💡 शेतीविषयक सर्वोत्तम सल्ले व मार्गदर्शन",
        chat_welcome_outro: "आज मी तुम्हाला कशी मदत करू शकतो?",
        msg_just_now: "आत्ताच",
        chip_crop_rec: "🌱 पिक शिफारसी",
        chip_soil_imp: "🌾 माती सुधारणा सल्ला",
        chip_market_price: "💰 बाजारभाव"
    }
};

let currentLang = localStorage.getItem('AgriIntel_lang') || 'en';
let currentLocationKey = localStorage.getItem('AgriIntel_weather_location') || 'pune';

// Function to change weather location
function changeWeatherLocation(locationKey) {
    if (!locationWeatherData[locationKey]) return;
    currentLocationKey = locationKey;
    localStorage.setItem('AgriIntel_weather_location', locationKey);

    const locData = locationWeatherData[locationKey];

    // Update Dropdown Value if called programmatically
    const selectEl = document.getElementById('weather-location-select');
    if (selectEl && selectEl.value !== locationKey) {
        selectEl.value = locationKey;
    }

    // Update Temperature & Humidity
    const tempEl = document.getElementById('weather-temp-val');
    if (tempEl) tempEl.innerText = locData.temp;

    const humidityEl = document.getElementById('weather-humidity-val');
    if (humidityEl) humidityEl.innerText = locData.humidity;

    // Update Warning Text
    const warningTextEl = document.getElementById('weather-warning-text');
    if (warningTextEl) {
        warningTextEl.innerText = currentLang === 'mr' ? locData.warning_mr : locData.warning_en;
    }

    // Update Location Badge
    const badgeEl = document.getElementById('weather-location-badge');
    if (badgeEl) {
        badgeEl.innerText = currentLang === 'mr' ? locData.name_mr : locData.name_en;
    }

    // Update Hero Title
    const heroTitleEl = document.getElementById('hero-title-text');
    if (heroTitleEl) {
        const cropFocus = currentLang === 'mr' ? locData.crop_focus_mr : locData.crop_focus_en;
        heroTitleEl.innerText = currentLang === 'mr' 
            ? `📍 स्मार्ट फार्मिंग कमांड सेंटर — ${cropFocus}` 
            : `📍 Smart Farming Command Center — ${cropFocus}`;
    }

    // Update Radar Footer
    const radarFooterEl = document.getElementById('radar-footer-text');
    if (radarFooterEl) {
        radarFooterEl.innerText = currentLang === 'mr'
            ? `स्थानिक निर्देशांक: ${locData.coords}`
            : `Field Coordinates: ${locData.coords}`;
    }

    console.log(`[AgriIntel Weather] Location changed to: ${locationKey}`);
}

// Function to switch app language
function switchLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('AgriIntel_lang', lang);

    // Update active button state
    document.getElementById('lang-en')?.classList.toggle('active', lang === 'en');
    document.getElementById('lang-mr')?.classList.toggle('active', lang === 'mr');

    // Translate elements with data-i18n attribute
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            el.innerText = translations[lang][key];
        }
    });

    // Translate placeholder attributes
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (translations[lang] && translations[lang][key]) {
            el.setAttribute('placeholder', translations[lang][key]);
        }
    });

    // Re-apply weather location text for new language
    changeWeatherLocation(currentLocationKey);

    console.log(`[AgriIntel i18n] Language switched to: ${lang}`);
}

// Tab navigation handler
document.addEventListener('DOMContentLoaded', () => {
    // Apply initial language & weather location
    switchLanguage(currentLang);
    changeWeatherLocation(currentLocationKey);

    const navLinks = document.querySelectorAll('.nav-link, .feature-btn');
    const sections = document.querySelectorAll('.feature-section');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('data-target');

            if (!targetId) return;

            // Deactivate all links & sections
            document.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));

            // Activate targeted link & section
            const activeNav = document.querySelector(`.nav-link[data-target="${targetId}"]`);
            if (activeNav) activeNav.classList.add('active');

            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add('active');
                targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});
