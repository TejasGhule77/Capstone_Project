/**
 * AgriIntel — Market Price Predictions Controller (Bilingual EN/MR Output)
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('market-prediction-form') || document.getElementById('market-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const outputCard = document.getElementById('market-prediction-results') || document.getElementById('market-results');
        const outputDiv = document.getElementById('market-prediction-output') || outputCard;
        const lang = localStorage.getItem('AgriIntel_lang') || 'en';

        if (outputCard) outputCard.style.display = 'block';

        const content = `
            <div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.3); padding: 1rem; border-radius: 10px;">
                <h4 style="margin: 0; color: #0284c7;">
                    ${lang === 'mr' ? '📈 अंदाज वर्तवलेला दर: ₹६५ - ₹७२ / किलो (तेजीचा कल)' : '📈 Forecasted Price: ₹65 - ₹72 / kg (Bullish Trend)'}
                </h4>
                <p style="margin: 0.5rem 0; font-size: 0.88rem; color: #334155;">
                    ${lang === 'mr' ? 'बाजार समिती: <strong>पुणे कृषी उत्पन्न बाजार समिती (APMC) / नाशिक मंडी</strong>' : 'Market: <strong>Pune APMC / Nashik Mandi</strong>'}
                </p>
                <div style="font-size: 0.85rem; color: #475569;">
                    💡 <strong>${lang === 'mr' ? 'विक्री सल्ला:' : 'Selling Advice:'}</strong> ${lang === 'mr' ? 'पुढील आठवड्यात आवक कमी असल्याने बाजारात मागणी वाढून दर उत्तम मिळण्याची शक्यता आहे.' : 'High demand expected next week due to seasonal market shortage.'}
                </div>
            </div>
        `;

        if (outputDiv && outputDiv !== outputCard) {
            outputDiv.innerHTML = content;
        } else if (outputCard) {
            outputCard.innerHTML = `<h3 data-i18n="title_market_results">${lang === 'mr' ? 'बाजारभाव अंदाज निकाल' : 'Market Prediction Results'}</h3>` + content;
        }
    });
});
