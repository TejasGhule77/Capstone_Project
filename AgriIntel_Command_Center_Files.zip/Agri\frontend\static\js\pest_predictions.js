/**
 * AgriIntel — Pest Predictions Controller (Bilingual EN/MR Output)
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('pest-prediction-form') || document.getElementById('pest-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const outputCard = document.getElementById('pest-prediction-results') || document.getElementById('pest-results');
        const outputDiv = document.getElementById('pest-prediction-output') || outputCard;
        const lang = localStorage.getItem('AgriIntel_lang') || 'en';

        if (outputCard) outputCard.style.display = 'block';

        const content = `
            <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.3); padding: 1rem; border-radius: 10px;">
                <h4 style="margin: 0; color: #d97706;">
                    ${lang === 'mr' ? '🦗 संभाव्य कीड: थ्रिप्स (Thrips) व पांढरी माशी (Mealybug) धोका (मध्यम तीव्रता)' : '🦗 Predicted Pest: Thrips / Mealybug Risk (Medium Severity)'}
                </h4>
                <p style="margin: 0.5rem 0; font-size: 0.88rem; color: #334155;">
                    ${lang === 'mr' ? 'धोका अंदाज अचूकता: <strong>८८%</strong>' : 'Risk Confidence: <strong>88%</strong>'}
                </p>
                <div style="font-size: 0.85rem; color: #475569;">
                    💡 <strong>${lang === 'mr' ? 'एकात्मिक कीड व्यवस्थापन (IPM) सल्ला:' : 'IPM Recommendation:'}</strong> ${lang === 'mr' ? 'पिवळे व निळे चिकट सापळे लावा आणि १०,००० ppm निंबोळी तेलाची फवारणी करा.' : 'Deploy sticky traps and spray Neem oil (10,000 ppm) solution.'}
                </div>
            </div>
        `;

        if (outputDiv && outputDiv !== outputCard) {
            outputDiv.innerHTML = content;
        } else if (outputCard) {
            outputCard.innerHTML = `<h3 data-i18n="title_pest_results">${lang === 'mr' ? 'कीड अंदाज निकाल' : 'Pest Prediction Results'}</h3>` + content;
        }
    });
});
