/**
 * AgriIntel — Crop & Fertilizer Recommendations Controller (Bilingual EN/MR Output)
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('recommendation-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const outputCard = document.getElementById('recommendation-results');
        const lang = localStorage.getItem('AgriIntel_lang') || 'en';

        if (outputCard) {
            outputCard.style.display = 'block';
            outputCard.innerHTML = `
                <h3>${lang === 'mr' ? 'पिक व खत शिफारस निकाल' : 'Crop & Fertilizer Recommendations'}</h3>
                <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.3); padding: 1rem; border-radius: 10px;">
                    <h4 style="margin: 0; color: #047857;">
                        ${lang === 'mr' ? '🌱 शिफारस केलेले पिक: द्राक्ष (Grapes) / ऊस (Sugarcane)' : '🌱 Recommended Crop: Grapes / Sugarcane'}
                    </h4>
                    <p style="margin: 0.5rem 0; font-size: 0.88rem; color: #334155;">
                        ${lang === 'mr' ? 'योग्य NPK प्रमाण: <strong>N=50, P=25, K=30</strong> | मातीचा सामू (pH): <strong>6.8</strong>' : 'Optimal NPK Balance: <strong>N=50, P=25, K=30</strong> | pH: <strong>6.8</strong>'}
                    </p>
                    <div style="font-size: 0.85rem; color: #475569;">
                        💡 <strong>${lang === 'mr' ? 'शिफारस केलेले खत:' : 'Recommended Fertilizer:'}</strong> ${lang === 'mr' ? 'NPK १५-१५-१५ (१२० किलो/हेक्टर) सोबत सेंद्रिय कडुनिंब पेंड वापरा.' : 'NPK 15-15-15 (120 kg/ha) with Bio-organic Neem Cake.'}
                    </div>
                </div>
            `;
        }
    });
});
