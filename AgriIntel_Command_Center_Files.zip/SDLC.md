# SDLC (Software Development Life Cycle) — AgriIntel (Agile + ML/AI)

This document describes a practical SDLC tailored to AgriIntel’s architecture (Django REST API + ML/DL model inference + frontend + N8N chatbot).

---

## 1) Planning & Requirements
### Objectives
- Define **what** to build and **why**.
- Define **success criteria** (accuracy, latency, reliability, UX).

### Activities
- Gather stakeholder requirements (farmers, developers, admin users).
- Write user stories per module:
  - Crop yield prediction
  - Disease detection (image upload)
  - Pest prediction
  - Crop & fertilizer recommendations
  - Market price prediction
  - AI chatbot via N8N webhook
- Define non-functional requirements (NFRs):
  - Security (auth, upload validation)
  - Performance (inference response time)
  - Availability and fallback behavior (webhook timeout → rule-based advice)
  - Scalability (model loading strategy, caching)
- Prioritize backlog items.

### Deliverables
- Product backlog / epics + user stories
- NFR checklist
- Acceptance criteria for each story

---

## 2) Analysis & Design
### Objectives
- Convert requirements into implementable design.

### Activities
- Architecture design:
  - Django REST endpoints (views/serializers/urls)
  - Inference wrappers for each model (preprocessing + prediction)
  - Frontend UI contracts (request/response shapes)
- API contract design:
  - Request/response schema
  - Validation rules and error formats
- ML/Data design:
  - Training vs inference separation
  - Model versioning (metadata + model artifacts)
  - Input feature mapping (raw inputs → model features)
- UX design for each workflow:
  - Form fields and labels
  - Display logic for confidence, explanations, and errors

### Deliverables
- API design notes (endpoint list + payload examples)
- Data/feature mapping docs
- System design overview

---

## 3) Development (Implementation)
### Objectives
- Implement features incrementally with frequent working releases.

### Activities
- Follow coding standards:
  - Python: PEP8, docstrings, consistent error handling
  - JS: modular functions for each API call
- Layered implementation:
  - API layer: serializers + views + URL routes
  - Inference layer: preprocessing and model inference utilities
  - Frontend: AJAX calls + rendering results
- Git workflow:
  - `feature/*` for new work
  - `bugfix/*` for fixes
  - small PRs with clear descriptions

### Definition of Done (DoD)
A story is Done only when:
- UI → API → inference → response works end-to-end
- Validation errors return consistent messages
- Basic logging exists for prediction failures
- No breaking changes to other endpoints

---

## 4) Testing
### Objectives
- Ensure correctness, stability, regression safety, and acceptable performance.

### Test Levels
1. **Unit tests**
   - Preprocessing functions
   - Payload validation and encoding
   - Prediction wrapper output format (confidence/type/explanation)
2. **Integration tests**
   - Django endpoints using test client
   - Disease upload endpoint with representative images
3. **System/End-to-End tests**
   - Frontend requests against running backend (manual or scripted)
4. **Performance & reliability**
   - Inference latency per endpoint
   - Model cold-start vs warm-start behavior
   - Webhook timeout handling (N8N failure simulation)
5. **ML quality checks**
   - Metric checks during training promotion
   - Class label mapping correctness
   - Output sanity checks

### Deliverables
- `/tests` updates (as applicable)
- Test run instructions
- Performance baseline notes

---

## 5) Deployment
### Objectives
- Release safely to staging/production.

### Activities
- Environment setup:
  - dev, staging, production
  - configure environment variables (model paths, debug mode, allowed hosts)
- Database migrations:
  - run migrations before enabling endpoints
- Static/media handling:
  - configure media storage for uploads
- Production server readiness:
  - use appropriate WSGI setup (e.g., Gunicorn behind Nginx)

### Deliverables
- Deployment checklist / runbook
- Environment variable template

---

## 6) Release, Monitoring & Incident Response
### Objectives
- Detect issues quickly and improve iteratively.

### Activities
- Logging:
  - request IDs, endpoint name, inference duration
  - capture exception stack traces with context
- Monitoring:
  - API error rate
  - endpoint latency percentiles
  - model load time
  - N8N webhook success rate and fallback usage
- Incident response playbook:
  - triage → mitigate → root-cause → patch

---

## 7) Maintenance & Continuous Improvement
### Objectives
- Keep the system stable and improve model quality over time.

### Activities
- Patch releases for bugs and dependency updates
- Model retraining cycle:
  - retrain → evaluate → version bump → rollout
- Regression checks for each model after updates
- Security maintenance:
  - review upload handling and dependency vulnerabilities

### Deliverables
- Maintenance log / changelog
- Model version history

---

## Suggested Repository Additions
Optional but helpful:
- `TODO-SDLC.md` (track SDLC tasks)
- `RUNBOOK.md` (deployment steps)
- `API_SPEC.md` (endpoint contracts)
- `TEST_PLAN.md` (test matrix)

